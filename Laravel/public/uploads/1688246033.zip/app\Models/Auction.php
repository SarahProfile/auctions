<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Auction extends Model 
{

    protected $table = 'auctions';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];

    public function bids()
    {
        return $this->hasMany('App\Models\Bid');
    }

    public function category()
    {
        return $this->belongsTo('App\Models\Category');
    }

}