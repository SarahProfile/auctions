<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::resource('types', 'TypesController');
Route::resource('category', 'CategoryController');
Route::resource('message', 'MessageController');
Route::resource('country', 'CountryController');
Route::resource('attribute', 'AttributeController');
Route::resource('ads', 'AdsController');
Route::resource('city', 'CityController');
Route::resource('auction', 'AuctionController');
Route::resource('user', 'UserController');
Route::resource('role', 'RoleController');
Route::resource('service', 'ServiceController');
Route::resource('attempt', 'AttemptController');
Route::resource('offer', 'OfferController');
Route::resource('bid', 'BidController');
Route::resource('design', 'DesignController');
Route::resource('requirment', 'RequirmentController');
